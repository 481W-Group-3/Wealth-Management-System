package com.wealth_management_system.BackWealthApp.security;

import lombok.Data;

@Data
public class JwtAuthResponse {
	
	private String token;

}
