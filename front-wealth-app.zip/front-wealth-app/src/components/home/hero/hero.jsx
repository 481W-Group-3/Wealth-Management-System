
const Hero = () => {
    return(
        <div>
            <p>Home Page</p>
        </div>
    )
}

export default Hero;