import UserCreate from "../components/user-create/account-creation.jsx";

const UserCreatePage = () => {
    return (
        <div>
            <UserCreate />
        </div>
    )
}

export default UserCreatePage;