import Hero from "../components/home/hero/hero.jsx";

const HomePage = () => {
    return(
        <div>
            <Hero/>
        </div>
    )
}

export default HomePage;


