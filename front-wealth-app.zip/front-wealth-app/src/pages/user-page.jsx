import User from "../components/user/user.jsx";

const UserPage = () => {
    return(
        <div>
            <User/>
        </div>
    )
}

export default UserPage;